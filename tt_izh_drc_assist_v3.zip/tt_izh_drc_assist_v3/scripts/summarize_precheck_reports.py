#!/usr/bin/env python3
"""Summarize Tiny Tapeout/KLayout precheck report XML files by rule category.
Usage:
  python3 scripts/summarize_precheck_reports.py precheck_reports.zip --out reports/precheck_summary.md
or:
  python3 scripts/summarize_precheck_reports.py precheck_dir --out reports/precheck_summary.md
"""
import argparse, collections, csv, os, tempfile, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

def iter_xmls(path: Path):
    if path.is_file() and path.suffix.lower() == '.zip':
        tmp = Path(tempfile.mkdtemp(prefix='tt_precheck_'))
        with zipfile.ZipFile(path) as z: z.extractall(tmp)
        yield from tmp.glob('*.xml')
    elif path.is_dir():
        yield from path.glob('*.xml')
    else:
        raise SystemExit(f'not a zip or directory: {path}')

def get_category_descriptions(root):
    desc = {}
    for cat in root.findall('.//category'):
        name = cat.findtext('name') or cat.attrib.get('name') or (cat.text or '').strip()
        description = cat.findtext('description') or ''
        if name and description:
            desc[name.strip("'")] = description
    return desc

def summarize(xml_files):
    rows = []
    for f in xml_files:
        if f.name == 'results.xml':
            continue
        try:
            root = ET.parse(f).getroot()
        except Exception as e:
            rows.append((f.name, 'PARSE_ERROR', 1, str(e)))
            continue
        desc = get_category_descriptions(root)
        counts = collections.Counter()
        for item in root.findall('.//item'):
            cat = item.findtext('category') or item.get('category') or 'UNKNOWN'
            cat = cat.strip().strip("'")
            counts[cat] += 1
        for cat, n in counts.most_common():
            rows.append((f.name, cat, n, desc.get(cat, '')))
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('precheck', type=Path)
    ap.add_argument('--out', type=Path, default=Path('precheck_summary.md'))
    ap.add_argument('--csv', type=Path, default=None)
    args = ap.parse_args()
    rows = summarize(list(iter_xmls(args.precheck)))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open('w', encoding='utf-8') as w:
        w.write('# Precheck DRC summary\n\n')
        w.write('| Report | Rule | Count | Description |\n')
        w.write('|---|---:|---:|---|\n')
        for report, rule, n, desc in rows:
            w.write(f'| {report} | `{rule}` | {n} | {desc.replace("|", "/")} |\n')
        w.write('\n## Suggested triage order\n\n')
        w.write('1. Fix structural/package checks first: unique top cell, invalid layer `(0,0)`, missing LEF `VGND`/`VDPWR`, and pin-label-over-drawing checks.\n')
        w.write('2. Fix off-grid violations next; these multiply every other rule error. Regenerate on a 5 nm/10 nm grid rather than manually editing thousands of vertices.\n')
        w.write('3. Fix exact-size cut/via/contact rules: `licon`, `mcon`, `via`, `via2`, `via3`. These must usually be exact squares in SKY130.\n')
        w.write('4. Only after those are gone, debug true device-level FEOL geometry and analog connectivity.\n')
    if args.csv:
        args.csv.parent.mkdir(parents=True, exist_ok=True)
        with args.csv.open('w', newline='', encoding='utf-8') as f:
            cw = csv.writer(f)
            cw.writerow(['report','rule','count','description'])
            cw.writerows(rows)
    print(f'wrote {args.out}')
    if args.csv: print(f'wrote {args.csv}')

if __name__ == '__main__': main()
