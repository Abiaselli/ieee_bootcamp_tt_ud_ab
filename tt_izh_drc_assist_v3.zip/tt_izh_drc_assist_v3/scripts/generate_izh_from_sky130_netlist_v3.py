#!/usr/bin/env python3
"""
Generate a netlist-aware Tiny Tapeout/SKY130 analog starter GDS + LEF from a
simple MOS netlist containing M-lines. Capacitors are intentionally omitted so
V and U can use external capacitance.

This is still a STARTER analog layout, not signoff. It improves over the prior
script by accepting explicit SKY130-style M-lines, snapping all geometry to a
5 nm grid, using exact-size licon/mcon/via/via2/via3 cuts, adding met4 drawing
under all met4 pin/label rectangles, adding LEF/GDS VGND/VDPWR pins, and avoiding
layer (0,0).
"""
from __future__ import annotations
import argparse, re, math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional

GRID = 0.005  # um, 5 nm

def q(x: float) -> float:
    return round(round(x / GRID) * GRID, 6)

def val_to_um(s: str) -> float:
    s = s.strip().lower()
    m = re.match(r'([-+0-9.]+(?:e[-+]?\d+)?)([a-z]*)$', s)
    if not m: raise ValueError(f'bad dimension {s!r}')
    v = float(m.group(1)); u = m.group(2)
    if u in ('u','um','µ','µm'): return v
    if u in ('n','nm'): return v * 1e-3
    if u in ('m','mm'): return v * 1e3
    if u in ('p','pm'): return v * 1e-6
    # LTspice netlists sometimes drop the 'n' in values copied from tables.
    # For our paper-derived transistor lengths like l=125, treat large bare
    # numbers as nm; small bare numbers as um.
    if not u and abs(v) > 10: return v * 1e-3
    return v

LAYER = {
    'pr_boundary': (235, 4),
    'nwell': (64, 20),
    'diff': (65, 20),
    'tap': (65, 44),
    'poly': (66, 20),
    'licon': (66, 44),
    'li1': (67, 20),
    'mcon': (67, 44),
    'met1': (68, 20), 'met1_pin': (68, 16), 'met1_label': (68, 5),
    'via': (68, 44),
    'met2': (69, 20), 'met2_pin': (69, 16),
    'via2': (69, 44),
    'met3': (70, 20), 'met3_pin': (70, 16),
    'via3': (70, 44),
    'met4': (71, 20), 'met4_pin': (71, 16), 'met4_label': (71, 5),
    'nsdm': (93, 44), 'psdm': (94, 20), 'npc': (95, 20),
}

NET_ALIAS = {'0':'VGND','VGnd':'VGND','VGND':'VGND','Vgnd':'VGND','Vdd':'VDPWR','VDD':'VDPWR','VPWR':'VDPWR','REQ':'REQ_N','Req':'REQ_N','Vd':'VD','Vc':'VC'}
PUBLIC_PIN_NETS = {'ua[0]':'V','ua[1]':'U','ua[2]':'VD','ua[3]':'VC','ui_in[0]':'ACK','uo_out[0]':'REQ_N'}
USED_OUTPUTS = {'uo_out[0]'}
MIN_W, MIN_L = 0.42, 0.15

@dataclass
class Pin:
    name: str; direction: str; cx: float; cy: float; llx: float; lly: float; urx: float; ury: float; layer_name: str='met4'
    @property
    def bbox(self): return ((self.cx+self.llx, self.cy+self.lly), (self.cx+self.urx, self.cy+self.ury))
    @property
    def center(self): return (self.cx, self.cy)

@dataclass
class DefTemplate:
    die: Tuple[float,float,float,float]
    pins: Dict[str, Pin]

@dataclass
class Device:
    name: str; kind: str; d: str; g: str; s: str; b: str; model: str; w: float; l: float; nf: int=1

def cn(n: str) -> str: return NET_ALIAS.get(n, n)

def parse_def(path: Path) -> DefTemplate:
    text = path.read_text()
    dbu = float(re.search(r'UNITS\s+DISTANCE\s+MICRONS\s+(\d+)', text).group(1))
    dm = re.search(r'DIEAREA\s*\(\s*([-0-9]+)\s+([-0-9]+)\s*\)\s*\(\s*([-0-9]+)\s+([-0-9]+)\s*\)', text)
    die = tuple(float(x)/dbu for x in dm.groups())
    pins: Dict[str, Pin] = {}
    block = re.search(r'PINS\s+\d+\s*;(.*?)END\s+PINS', text, flags=re.S).group(1)
    for chunk in re.split(r'\n\s*-\s+', block):
        chunk = chunk.strip().lstrip('-').strip()
        if not chunk: continue
        nm = re.match(r'([^\s]+)', chunk)
        dm = re.search(r'\+\s+DIRECTION\s+(\w+)', chunk)
        lm = re.search(r'\+\s+LAYER\s+(\w+)\s+\(\s*([-0-9]+)\s+([-0-9]+)\s*\)\s+\(\s*([-0-9]+)\s+([-0-9]+)\s*\)', chunk)
        pm = re.search(r'\+\s+PLACED\s+\(\s*([-0-9]+)\s+([-0-9]+)\s*\)', chunk)
        if not (nm and dm and lm and pm): continue
        llx,lly,urx,ury = [float(v)/dbu for v in lm.groups()[1:]]
        cx,cy = [float(v)/dbu for v in pm.groups()]
        pins[nm.group(1)] = Pin(nm.group(1), dm.group(1), cx, cy, llx,lly,urx,ury, lm.group(1))
    return DefTemplate(die, pins)

def parse_netlist(path: Path, size_mode: str) -> List[Device]:
    devs: List[Device] = []
    for raw in path.read_text(errors='ignore').splitlines():
        line = raw.strip()
        if not line or line[0] in '*.': continue
        line = line.split(';',1)[0].strip()
        toks = line.split()
        if not toks: continue
        if toks[0][0].upper() == 'C':
            continue  # external caps only
        if toks[0][0].upper() != 'M' or len(toks) < 6:
            continue
        name,d,g,s,b,model = toks[:6]
        rest = ' '.join(toks[6:])
        wm = re.search(r'\bw\s*=\s*([^\s]+)', rest, re.I)
        lm = re.search(r'\bl\s*=\s*([^\s]+)', rest, re.I)
        nf = int(re.search(r'\bnf\s*=\s*(\d+)', rest, re.I).group(1)) if re.search(r'\bnf\s*=\s*(\d+)', rest, re.I) else 1
        w = val_to_um(wm.group(1)) if wm else MIN_W
        l = val_to_um(lm.group(1)) if lm else MIN_L
        if size_mode == 'ratio_scaled':
            sc = max(1.0, MIN_W/max(w,1e-9), MIN_L/max(l,1e-9)); w,l = w*sc,l*sc
        elif size_mode == 'sky130_min':
            w,l = max(w,MIN_W), max(l,MIN_L)
        elif size_mode == 'paper':
            pass
        else:
            raise ValueError(size_mode)
        kind = 'pfet' if model.upper().startswith('P') else 'nfet'
        devs.append(Device(name, kind, cn(d),cn(g),cn(s),cn(b), model, q(w), q(l), nf))
    if not devs: raise SystemExit(f'No MOS M-lines found in {path}')
    return devs

def import_gf():
    try: import gdsfactory as gf
    except Exception as e: raise SystemExit('Install gdsfactory first: python3 -m pip install --user gdsfactory\n'+str(e))
    return gf

def rect(c, x0,y0,x1,y1, layer, label: Optional[str]=None, label_layer=None):
    x0,y0,x1,y1 = map(q, (x0,y0,x1,y1))
    if x1 < x0: x0,x1=x1,x0
    if y1 < y0: y0,y1=y1,y0
    c.add_polygon([(x0,y0),(x1,y0),(x1,y1),(x0,y1)], layer=layer)
    if label:
        c.add_label(label, position=(q((x0+x1)/2), q((y0+y1)/2)), layer=label_layer or LAYER['met4_label'])

def mrect(c, p0, p1, width, layer):
    x0,y0=p0; x1,y1=p1; width=q(width)
    if abs(x1-x0) >= abs(y1-y0): rect(c, min(x0,x1), y0-width/2, max(x0,x1), y0+width/2, layer)
    else: rect(c, x0-width/2, min(y0,y1), x0+width/2, max(y0,y1), layer)

def lab(c, text, pos, layer=LAYER['met4_label']): c.add_label(text, position=(q(pos[0]),q(pos[1])), layer=layer)

def cut(c, x,y,size,layer): rect(c, x-size/2, y-size/2, x+size/2, y+size/2, layer)

def via_m1_to_m4(c, x,y):
    # exact cuts + generous legal-ish metal enclosures, all centered
    cut(c,x,y,0.15,LAYER['via']);  rect(c,x-0.18,y-0.18,x+0.18,y+0.18,LAYER['met1']); rect(c,x-0.22,y-0.22,x+0.22,y+0.22,LAYER['met2'])
    cut(c,x,y,0.20,LAYER['via2']); rect(c,x-0.24,y-0.24,x+0.24,y+0.24,LAYER['met2']); rect(c,x-0.30,y-0.30,x+0.30,y+0.30,LAYER['met3'])
    cut(c,x,y,0.20,LAYER['via3']); rect(c,x-0.30,y-0.30,x+0.30,y+0.30,LAYER['met3']); rect(c,x-0.32,y-0.32,x+0.32,y+0.32,LAYER['met4'])

def contact_diff_to_m1(c, x,y):
    cut(c,x,y,0.17,LAYER['licon'])
    rect(c,x-0.18,y-0.18,x+0.18,y+0.18,LAYER['li1'])
    cut(c,x,y,0.17,LAYER['mcon'])
    rect(c,x-0.22,y-0.22,x+0.22,y+0.22,LAYER['met1'])

def draw_mos(c, d: Device, x: float, y: float):
    w=max(d.w,MIN_W); l=max(d.l,MIN_L); sd=0.64; gate_ext=0.36
    active_len=2*sd+l
    ax0,ax1=x-active_len/2,x+active_len/2; ay0,ay1=y-w/2,y+w/2
    if d.kind=='pfet':
        rect(c, ax0-0.84, ay0-0.84, ax1+0.84, ay1+0.84, LAYER['nwell'])
        rect(c, ax0-0.28, ay0-0.28, ax1+0.28, ay1+0.28, LAYER['psdm'])
    else:
        rect(c, ax0-0.28, ay0-0.28, ax1+0.28, ay1+0.28, LAYER['nsdm'])
    rect(c, ax0, ay0, ax1, ay1, LAYER['diff'])
    rect(c, x-l/2, ay0-gate_ext, x+l/2, ay1+gate_ext, LAYER['poly'])
    dpos=(q(ax0+0.24), q(y)); spos=(q(ax1-0.24), q(y)); gpos=(q(x), q(ay1+0.72))
    # source/drain contacts
    for pos, net, term in [(dpos,d.d,'D'),(spos,d.s,'S')]:
        contact_diff_to_m1(c,*pos); rect(c,pos[0]-0.30,pos[1]-0.24,pos[0]+0.30,pos[1]+0.24,LAYER['met1'],f'{d.name}.{term}:{net}',LAYER['met1_label'])
        lab(c,net,pos,LAYER['met1_label'])
    # poly/gate contact above active, with npc marker
    rect(c, gpos[0]-0.30,gpos[1]-0.30,gpos[0]+0.30,gpos[1]+0.30,LAYER['npc'])
    rect(c, gpos[0]-0.085,gpos[1]-0.24,gpos[0]+0.085,ay1+gate_ext,LAYER['poly'])
    contact_diff_to_m1(c,*gpos)  # same physical cut stack; polygon is over poly/npc, not diff
    rect(c,gpos[0]-0.30,gpos[1]-0.24,gpos[0]+0.30,gpos[1]+0.24,LAYER['met1'],f'{d.name}.G:{d.g}',LAYER['met1_label'])
    lab(c,d.g,gpos,LAYER['met1_label'])
    lab(c,f'{d.name} {d.kind} W={w:.3g} L={l:.3g}',(x,ay0-1.25),LAYER['met1_label'])
    return {'D':dpos,'S':spos,'G':gpos,'B':spos}

def positions(devs, die):
    x0,y0,x1,y1=die; left=x0+13; dx=13.5
    rows={0: y0+55, 1: y0+92, 2: y0+129, 3: y0+166}
    pos={}
    for i,d in enumerate(devs):
        row=i//6; col=i%6
        pos[d.name]=(q(left+col*dx), q(rows.get(row, y0+55+row*37)))
    return pos

def collect_nets(devs):
    nets=set()
    for d in devs: nets.update([d.d,d.g,d.s,d.b])
    pref=['VGND','VDPWR','V','U','VD','VC','ACK','REQ_N','N001','N002','N003','N004','N005','N006','N007']
    return [n for n in pref if n in nets]+sorted(nets-set(pref))

def tracks(nets, die):
    x0,y0,x1,y1=die; base=y0+18; pitch=3.2
    return {n:q(base+i*pitch) for i,n in enumerate(nets)}

def add_pins(c,tpl,top):
    x0,y0,x1,y1=tpl.die; rect(c,x0,y0,x1,y1,LAYER['pr_boundary']); lab(c,top,((x0+x1)/2,y1-6))
    for p in tpl.pins.values():
        (a,b)=p.bbox
        # TT pin: drawing underneath + pin purpose + label on top.
        rect(c,a[0],a[1],b[0],b[1],LAYER['met4'])
        rect(c,a[0],a[1],b[0],b[1],LAYER['met4_pin'])
        lab(c,p.name,p.center,LAYER['met4_label'])

def route_pins(c,tpl,tr):
    for pin,net in PUBLIC_PIN_NETS.items():
        if pin in tpl.pins and net in tr:
            x,y=tpl.pins[pin].center; ty=tr[net]
            mrect(c,(x,y),(x,ty),0.62,LAYER['met4']); lab(c,f'{pin}:{net}',(x+1,(y+ty)/2))
    if 'VGND' in tr:
        for p in tpl.pins.values():
            is_unused = (p.name.startswith('uo_out[') and p.name not in USED_OUTPUTS) or p.name.startswith('uio_out[') or p.name.startswith('uio_oe[')
            if is_unused:
                x,y=p.center; mrect(c,(x,y),(x,tr['VGND']),0.32,LAYER['met4'])

def route_all(c,devs,term,tr,die):
    x0,y0,x1,y1=die
    for net,y in tr.items():
        width=0.50 if net in {'VGND','VDPWR','V','U'} else 0.32
        mrect(c,(x0+6,y),(x1-6,y),width,LAYER['met4']); lab(c,net,(x1-12,y+0.6))
    for d in devs:
        for term_name,net in [('D',d.d),('G',d.g),('S',d.s)]:
            x,y=term[d.name][term_name]; via_m1_to_m4(c,x,y); mrect(c,(x,y),(x,tr[net]),0.30,LAYER['met4'])

def add_power_pins(c,die,tr):
    # Internal abstract power pins for LEF/precheck. Do not use met5.
    x0,y0,x1,y1=die
    for net in ['VGND','VDPWR']:
        if net in tr:
            y=tr[net]
            rect(c,x0+5,y-0.55,x1-5,y+0.55,LAYER['met4'])
            rect(c,x0+5,y-0.55,x1-5,y+0.55,LAYER['met4_pin'])
            lab(c,net,(x0+10,y),LAYER['met4_label'])

def write_lef(path: Path, top: str, tpl: DefTemplate, tr: Dict[str,float]):
    x0,y0,x1,y1=tpl.die; w=x1-x0; h=y1-y0
    lines=['VERSION 5.8 ;','BUSBITCHARS "[]" ;','DIVIDERCHAR "/" ;','UNITS','  DATABASE MICRONS 1000 ;','END UNITS',f'MACRO {top}','  CLASS BLOCK ;',f'  FOREIGN {top} 0.000 0.000 ;','  ORIGIN 0.000 0.000 ;',f'  SIZE {w:.3f} BY {h:.3f} ;','  SYMMETRY X Y R90 ;']
    def add_pin(name,direction,use,rects):
        lines.append(f'  PIN {name}'); lines.append(f'    DIRECTION {direction} ;'); lines.append(f'    USE {use} ;'); lines.append('    PORT'); lines.append('      LAYER met4 ;')
        for a,b in rects: lines.append(f'        RECT {a[0]:.3f} {a[1]:.3f} {b[0]:.3f} {b[1]:.3f} ;')
        lines.append('    END'); lines.append(f'  END {name}')
    for p in tpl.pins.values():
        add_pin(p.name,p.direction.upper(),'SIGNAL',[p.bbox])
    for net in ['VGND','VDPWR']:
        if net in tr:
            y=tr[net]; use='GROUND' if net=='VGND' else 'POWER'
            add_pin(net,'INOUT',use,[((5.0,y-0.55),(w-5.0,y+0.55))])
    lines.append('  OBS')
    for layer in ['li1','met1','met2','met3','met4']:
        lines.append(f'    LAYER {layer} ;'); lines.append(f'      RECT 3.000 4.000 {w-3:.3f} {h-4:.3f} ;')
    lines.append('  END'); lines.append(f'END {top}'); lines.append('END LIBRARY')
    path.parent.mkdir(parents=True,exist_ok=True); path.write_text('\n'.join(lines)+'\n')

def write_spice(path: Path, devs: List[Device]):
    path.parent.mkdir(parents=True,exist_ok=True)
    ports=['V','U','VD','VC','ACK','REQ_N','VDPWR','VGND']
    out=[f'.subckt izh_sky130_macro_vu_vd_vc {" ".join(ports)}']
    for d in devs:
        model='sky130_fd_pr__pfet_01v8' if d.kind=='pfet' else 'sky130_fd_pr__nfet_01v8'
        out.append(f'{d.name} {d.d} {d.g} {d.s} {d.b} {model} w={d.w:.4g}u l={d.l:.4g}u nf={d.nf}')
    out += ['* capacitors intentionally external on V and U','.ends izh_sky130_macro_vu_vd_vc','']
    path.write_text('\n'.join(out))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--def',dest='def_path',type=Path,required=True)
    ap.add_argument('--netlist',type=Path,required=True)
    ap.add_argument('--top',default='tt_um_abiaselli_UDIZH1')
    ap.add_argument('--out-gds',type=Path,required=True)
    ap.add_argument('--out-lef',type=Path,required=True)
    ap.add_argument('--out-spice',type=Path,default=None)
    ap.add_argument('--report',type=Path,default=None)
    ap.add_argument('--size-mode',choices=['paper','sky130_min','ratio_scaled'],default='ratio_scaled')
    args=ap.parse_args()
    gf=import_gf(); tpl=parse_def(args.def_path); devs=parse_netlist(args.netlist,args.size_mode)
    c=gf.Component(args.top); add_pins(c,tpl,args.top)
    pos=positions(devs,tpl.die); term={}
    for d in devs: term[d.name]=draw_mos(c,d,*pos[d.name])
    tr=tracks(collect_nets(devs),tpl.die); route_all(c,devs,term,tr,tpl.die); route_pins(c,tpl,tr); add_power_pins(c,tpl.die,tr)
    args.out_gds.parent.mkdir(parents=True,exist_ok=True); c.write_gds(args.out_gds)
    write_lef(args.out_lef,args.top,tpl,tr)
    if args.out_spice: write_spice(args.out_spice,devs)
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        with args.report.open('w') as f:
            f.write(f'top={args.top}\nnetlist={args.netlist}\nmos_devices={len(devs)}\nsize_mode={args.size_mode}\n')
            for d in devs: f.write(f'{d.name:>4} {d.kind:4} D={d.d:8} G={d.g:8} S={d.s:8} B={d.b:8} W={d.w:.4g} L={d.l:.4g}\n')
    print(f'wrote {args.out_gds}\nwrote {args.out_lef}')
if __name__=='__main__': main()
