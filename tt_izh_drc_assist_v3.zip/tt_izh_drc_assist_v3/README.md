# TT Izhikevich SKY130 DRC assist v3

This package adds three helpers:

1. `scripts/generate_izh_from_sky130_netlist_v3.py` — accepts the newer MOS `M... PMOS/NMOS w=... l=...` LTspice netlist, omits capacitors, and regenerates a pin-correct starter GDS/LEF with better grid/via/contact handling.
2. `scripts/summarize_precheck_reports.py` — parses Tiny Tapeout precheck XML reports and ranks DRC errors by rule.
3. `layouteditor/sky130_tiny_triage.layout` — a LayoutEditor C++ macro for quick visual/rough DRC triage on Windows. It is not a replacement for the Tiny Tapeout precheck deck.

## Regenerate from the newer netlist

```bash
mkdir -p gds lef reports spice
python3 scripts/generate_izh_from_sky130_netlist_v3.py \
  --def def/tt_analog_1x2.def \
  --netlist spice/izhsky1304.cir \
  --top tt_um_abiaselli_UDIZH1 \
  --out-gds gds/tt_um_abiaselli_UDIZH1.gds \
  --out-lef lef/tt_um_abiaselli_UDIZH1.lef \
  --out-spice spice/izh_sky130_layout_start.spice \
  --report reports/izh_layout_report.txt \
  --size-mode ratio_scaled
```

Use `--size-mode sky130_min` to clamp W/L independently, or `--size-mode paper` to preserve literal dimensions from the netlist. `ratio_scaled` is the safer first pass.

## Summarize precheck output

```bash
python3 scripts/summarize_precheck_reports.py precheck_reports.zip \
  --out reports/precheck_summary.md \
  --csv reports/precheck_summary.csv
```

## LayoutEditor macro

In LayoutEditor on Windows:

1. Open the generated GDS.
2. Open/edit/execute `layouteditor/sky130_tiny_triage.layout` as a macro.
3. Use it only as a fast rough filter. Final pass/fail should still be Tiny Tapeout precheck/KLayout/Magic.

The macro intentionally runs only broad checks. A full SKY130 deck has many datatype-specific and context-specific rules that this simple macro does not implement.

## What this fixes vs. the prior generator

- Parses M-line MOS netlists directly.
- Leaves `Cu`, `Cv`, and `C1` external/omitted.
- Snaps generated shapes to a 5 nm grid.
- Avoids layer `(0,0)`.
- Adds met4 drawing under met4 pin/label shapes.
- Adds abstract `VGND` and `VDPWR` LEF/GDS pins.
- Uses exact-size starter cuts for `licon`, `mcon`, `via`, `via2`, and `via3`.

It is still a generated starter layout, not signoff-quality analog layout. Expect to continue iterating on FEOL device geometry, body taps, guard rings, and LVS.
